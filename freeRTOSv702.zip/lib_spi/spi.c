/*
 * Copyright (c) 2010 by Cristian Maglie <c.maglie@bug.st>
 * SPI Master library for arduino.
 *
 * This file is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU General Public License version 2
 * or the GNU Lesser General Public License version 2.1, both as
 * published by the Free Software Foundation.
 */

#include <spi.h>

void spiBegin()
{
	// Set direction register for SCK and MOSI pin.
	// MISO pin automatically overrides to INPUT.
	// When the SS pin is set as OUTPUT, it can be used as
	// a general purpose output port (it doesn't influence
	// SPI operations).

	SPI_PORT_DIR |= SPI_BIT_MOSI | SPI_BIT_SCK | SPI_BIT_SS;
	SPI_PORT_DIR &= ~SPI_BIT_MISO;

	SPI_PORT &= ~(SPI_BIT_MOSI | SPI_BIT_SCK);
	SPI_PORT |= SPI_BIT_SS;

	// Warning: if the SS pin ever becomes a LOW INPUT then SPI
	// automatically switches to Slave, so the data direction of
	// the SS pin MUST be kept as OUTPUT.
	SPCR |= _BV(MSTR);
	SPCR |= _BV(SPE);
}

void spiEnd()
{
	SPCR &= ~_BV(SPE);
}

void spiSetClockDivider(uint8_t rate)
{
	SPCR = (SPCR & ~SPI_CLOCK_MASK) | (rate & SPI_CLOCK_MASK);
	SPSR = (SPSR & ~SPI_2XCLOCK_MASK) | ((rate >> 2) & SPI_2XCLOCK_MASK);
}

void spiSetBitOrder(uint8_t bitOrder)
{
	if(bitOrder == SPI_LSBFIRST) {
		SPCR |= _BV(DORD);
	} else {
		SPCR &= ~(_BV(DORD));
	}
}

void spiSetDataMode(uint8_t mode)
{
	SPCR = (SPCR & ~SPI_MODE_MASK) | mode;
}


void spiAttachInterrupt()
{
	SPCR |= _BV(SPIE);
}

void spiDetachInterrupt()
{
	SPCR &= ~_BV(SPIE);
}

uint8_t spiTransfer(uint8_t _data)
{
	// If the SPI module has not been enabled yet, then enable it with default parameters.
	if ( !(SPCR & (1<<SPE)) )
	{
		spiBegin();
	}

	if (!(SPCR&(1<<MSTR)))
	{
		// The SPI module is enabled, but it is in slave mode, so we can not
		// transmit the byte.  This can happen if SSbar is an input and
		// it went low.

		// We will try to recover by setting the MSTR bit.
		SPCR |= 1<<MSTR;
	}

	// Pull slave select low to indicate start of transfer.
	SPI_SS(0);

	SPDR = _data; 	// Begin transmission

	while (!(SPSR & _BV(SPIF)))
	{
		if (!(SPCR & _BV(MSTR)))
		{
			// The SPI module has left master mode, so return.
			// Otherwise, this will be an infinite loop.
			return 0;
		}
	}

	// Pull slave select high to indicate end of transfer.
	SPI_SS(1);

	return SPDR;
}
