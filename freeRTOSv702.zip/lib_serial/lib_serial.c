/*
    FreeRTOS V7.0.1 - Copyright (C) 2011 Real Time Engineers Ltd.
	

    ***************************************************************************
     *                                                                       *
     *    FreeRTOS tutorial books are available in pdf and paperback.        *
     *    Complete, revised, and edited pdf reference manuals are also       *
     *    available.                                                         *
     *                                                                       *
     *    Purchasing FreeRTOS documentation will not only help you, by       *
     *    ensuring you get running as quickly as possible and with an        *
     *    in-depth knowledge of how to use FreeRTOS, it will also help       *
     *    the FreeRTOS project to continue with its mission of providing     *
     *    professional grade, cross platform, de facto standard solutions    *
     *    for microcontrollers - completely free of charge!                  *
     *                                                                       *
     *    >>> See http://www.FreeRTOS.org/Documentation for details. <<<     *
     *                                                                       *
     *    Thank you for using FreeRTOS, and thank you for your support!      *
     *                                                                       *
    ***************************************************************************


    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    >>>NOTE<<< The modification to the GPL is included to allow you to
    distribute a combined work that includes FreeRTOS without being obliged to
    provide the source code for proprietary components outside of the FreeRTOS
    kernel.  FreeRTOS is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public
    License and the FreeRTOS license exception along with FreeRTOS; if not it
    can be viewed here: http://www.freertos.org/a00114.html and also obtained
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

/*
Changes from V1.2.3

	+ The function xPortInitMinimal() has been renamed to 
	  xSerialPortInitMinimal() and the function xPortInit() has been renamed
	  to xSerialPortInit().

Changes from V2.0.0

	+ Delay periods are now specified using variables and constants of
	  portTickType rather than unsigned long.
	+ xQueueReceiveFromISR() used in place of xQueueReceive() within the ISR.

Changes from V2.6.0

	+ Replaced the inb() and outb() functions with direct memory
	  access.  This allows the port to be built with the 20050414 build of
	  WinAVR.
*/

/* BASIC INTERRUPT DRIVEN SERIAL PORT DRIVER. */
/* Also with polling serial functions, for use before scheduler is enabled */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include <util/delay.h>

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

#include <lib_serial.h>


/*-----------------------------------------------------------*/

#define vInterruptOn()										\
{															\
	uint8_t ucByte;								    		\
															\
	ucByte = UCSR0B;									    \
	ucByte |= serTX_INT_ENABLE;								\
	UCSR0B = ucByte;										\
}																				


#define vInterruptOff()										\
{															\
	uint8_t ucInByte;								   		\
															\
	ucInByte = UCSR0B;										\
	ucInByte &= ~serTX_INT_ENABLE;							\
	UCSR0B = ucInByte;										\
}


static xQueueHandle xRxedChars;
static xQueueHandle xCharsForTx;

/*-----------------------------------------------------------------*/

// xSerialPrintf_P(PSTR("\r\nMessage %u %u %u"), var1, var2, var2);

void xSerialPrintf( char * format, ...)
{
	va_list arg;
	char temp[80];

	va_start(arg, format);
	vsnprintf(temp, 80, format, arg);
	xSerialPrint(temp);
	va_end(arg);
}

void xSerialPrintf_P(PGM_P format, ...)
{
	va_list arg;
	char temp[80];

	va_start(arg, format);
	vsnprintf_P(temp, 80, format, arg);
	xSerialPrint(temp);
	va_end(arg);
}

void xSerialPrint( char * str)
{
	int16_t i = 0;
	size_t stringlength;

	stringlength = strlen(str);

	while(i < stringlength)
		xSerialPutChar( xSerialPort, str[i++], xNoBlock );
}

void xSerialPrint_P(PGM_P str)
{
	uint16_t i = 0;
	size_t stringlength;

	stringlength = strlen_P(str);

	while(i < stringlength)
		xSerialPutChar( xSerialPort, pgm_read_byte(&str[i++]), xNoBlock );
}

/*-----------------------------------------------------------*/

portBASE_TYPE xSerialGetChar( xComPortHandle pxPort, int8_t *pcRxedChar, portTickType xBlockTime )
{
	/* Only one port is supported. */
	( void ) pxPort;

	/* Get the next character from the buffer.  Return false if no characters
	are available, or arrive before xBlockTime expires. */
	if( xQueueReceive( xRxedChars, pcRxedChar, xBlockTime ) )
	{
		return pdTRUE;
	}
	else
	{
		return pdFALSE;
	}
}


portBASE_TYPE xSerialPutChar( xComPortHandle pxPort, int8_t cOutChar, portTickType xBlockTime )
{
	/* Only one port is supported. */
	( void ) pxPort;

	/* Return false if after the block time there is no room on the Tx queue. */
	if( xQueueSendToBack( xCharsForTx, &cOutChar, xBlockTime ) != pdPASS )
	{
		return pdFAIL;
	}

	vInterruptOn();

	return pdPASS;
}

/*-----------------------------------------------------------*/

xComPortHandle xSerialPortInitMinimal( unsigned long ulWantedBaud, portBASE_TYPE uxTxQueueLength, portBASE_TYPE uxRxQueueLength )
{
unsigned long ulBaudRateCounter;
uint8_t ucByte;

	portENTER_CRITICAL();
	{
		/* Create the queues used by the serial communications task. */

		xRxedChars = xQueueCreate( uxRxQueueLength, ( portBASE_TYPE ) sizeof( portBASE_TYPE ) );
		xCharsForTx = xQueueCreate( uxTxQueueLength, ( portBASE_TYPE ) sizeof( portBASE_TYPE ) );

		/* Calculate the baud rate register value from the equation in the
		data sheet. */
		ulBaudRateCounter = ( configCPU_CLOCK_HZ / ( serBAUD_DIV_CONSTANT * ulWantedBaud ) ) - ( unsigned long ) 1;

		/* Set the baud rate. */
		ucByte = ( uint8_t ) ( ulBaudRateCounter & ( unsigned long ) 0xff );
		UBRR0L = ucByte;

		ulBaudRateCounter >>= ( unsigned long ) 8;
		ucByte = ( uint8_t ) ( ulBaudRateCounter & ( unsigned long ) 0xff );
		UBRR0H = ucByte;

		/* Enable the Rx interrupt.  The Tx interrupt will get enabled
		later. Also enable the Rx and Tx. */
		UCSR0B = ( serRX_INT_ENABLE | serRX_ENABLE | serTX_ENABLE );

		/* Set the data bits to 8. */
		UCSR0C = ( serUCSRC_SELECT | serEIGHT_DATA_BITS );
	}
	portEXIT_CRITICAL();

	/* Unlike other ports, this serial code does not allow for more than one
	com port.  We therefore don't return a pointer to a port structure and can
	instead just return NULL. */
	return NULL;
}


void vSerialClose( xComPortHandle xPort )
{
	uint8_t ucByte;

	/* The parameter is not used. */
	( void ) xPort;

	/* Turn off the interrupts.  We may also want to delete the queues and/or
	re-install the original ISR. */

	portENTER_CRITICAL();
	{
		vInterruptOff();
		ucByte = UCSR0B;
		ucByte &= ~serRX_INT_ENABLE;
		UCSR0B = ucByte;
	}
	portEXIT_CRITICAL();
}

/*-----------------------------------------------------------*/

// polling read and write routines, for use before freeRTOS vTaskStartScheduler
// same as above, but doesn't use interrupts.

void avrSerialPrintf(char * format, ...)
{
	va_list arg;
	char temp[80];

	va_start(arg, format);
	vsnprintf(temp, 80, format, arg);
	avrSerialPrint(temp);
	va_end(arg);
}

void avrSerialPrintf_P(PGM_P format, ...)
{
	va_list arg;
	char temp[80];

	va_start(arg, format);
	vsnprintf_P(temp, 80, format, arg);
	avrSerialPrint(temp);
	va_end(arg);
}

void avrSerialPrint(char * str)
{
	uint16_t i = 0;
	size_t stringlength;

	stringlength = strlen(str);

	while(i < stringlength)
		avrSerialWrite(str[i++]);
}

void avrSerialPrint_P(PGM_P str)
{
	int i = 0;
	size_t stringlength;

	stringlength = strlen_P(str);

	while(i < stringlength)
		avrSerialWrite(pgm_read_byte(&str[i++]));
}

void avrSerialWrite(int8_t DataOut)
{
	while (!avrSerialCheckTxReady())		// while NOT ready to transmit
        _delay_ms(1);     					// delay
	UDR0 = DataOut;
}

int8_t avrSerialRead(void)
{
	while (!avrSerialCheckRxComplete())		// While data is NOT available to read
		_delay_ms(1);     					// delay
	return UDR0;
}

uint8_t avrSerialCheckRxComplete(void)
{
	return( UCSR0A & (1 << RXC0) );			// nonzero if serial data is available to read.
}

uint8_t avrSerialCheckTxReady(void)
{
	return( UCSR0A & (1 << UDRE0) );		// nonzero if transmit register is ready to receive new data.
}


/*-----------------------------------------------------------*/
#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__) || defined(__AVR_ATmega1284P__)
ISR( USART0_RX_vect )
#elif  defined(__AVR_ATmega1284P__)
ISR( USART0_RX_vect )
#elif defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__)
ISR( USART_RX_vect )
#endif
{
	int8_t cChar;
signed portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	/* Get the character and post it on the queue of Rxed characters.
	If the post causes a task to wake force a context switch as the awoken task
	may have a higher priority than the task we have interrupted. */
	cChar = UDR0;

	xQueueSendToBackFromISR( xRxedChars, &cChar, &xHigherPriorityTaskWoken );

	if( xHigherPriorityTaskWoken != pdFALSE )
	{
		taskYIELD();
	}
}
/*-----------------------------------------------------------*/

#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__) || defined(__AVR_ATmega1284P__)
ISR( USART0_UDRE_vect )
#elif  defined(__AVR_ATmega1284P__)
ISR( USART0_UDRE_vect )
#elif defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__)
ISR( USART_UDRE_vect )
#endif
{
	int8_t cChar;
	int8_t cTaskWoken;

	if( xQueueReceiveFromISR( xCharsForTx, &cChar, &cTaskWoken ) == pdTRUE )
	{
		/* Send the next character queued for Tx. */
		UDR0 = cChar;
	}
	else
	{
		/* Queue empty, nothing to send. */
		vInterruptOff();
	}
}
